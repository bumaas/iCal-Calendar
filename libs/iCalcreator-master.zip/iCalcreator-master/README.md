# iCalcreator

is the PHP class package managing

> iCal (rfc2445/rfc5445) information

operating on calendar and
calendar events, reports, todos and journaling data.

iCalcreator supports systems like
 * calendars
 * CMS
 * project management systems
 * other applications...

Builds
- stable 2.24 *(master)*
- old 2.22.5 *(tag)* - unsupported
